package com.zeroblur.app;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.SurfaceTexture;
import android.graphics.drawable.Drawable;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import android.util.Range;
import android.util.Size;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;

import java.util.Arrays;

import android.content.Intent;
import android.provider.MediaStore;
import android.net.Uri;
import okhttp3.*;
import android.app.Dialog;
import android.widget.ImageView;
import android.graphics.BitmapFactory;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.IOException;
import android.app.ProgressDialog;

public class CameraActivity extends AppCompatActivity {
    private static final int REQUEST_CAMERA_PERMISSION = 100;
    private static final String TAG = "CameraActivity";

    private TextureView textureView;
    private TextView isoText;
    private TextView exposureText;
    private TextView shutterText;
    private TextView blurResultText; // Added for blur detection result
    private TextView isoTextView, shutterTextView;
    private SeekBar isoSlider;
    private SeekBar shutterSlider;
    private CameraDevice cameraDevice;
    private CameraCaptureSession cameraCaptureSession;
    private String cameraId;
    private CaptureRequest.Builder captureBuilder;
    int nano = 1000000000;
    private long[] shutterSpeeds = {

               250000L,      // 1/4000s
               500000L,      // 1/2000s
              1000000L,      // 1/1000s
              2000000L,      // 1/500s
              4000000L,      // 1/250s
             10000000L,     // 1/100s
             20000000L,     // 1/50s
             33333333L,     // 1/30s
            100000000L,    // 1/10s
            200000000L,    // 1/5s
            500000000L,     // 0.5s
            1000000000L     // 1s
    };
    private int[] isoValues = {100, 200, 400, 800, 1600, 3200};

    private BlurClassificationHelper blurClassifier;
    private Handler backgroundHandler;
    private HandlerThread backgroundThread;
    private long lastProcessedTimestamp = 0;
    private static final long PROCESS_INTERVAL_MS = 200; // Process every 500ms

    boolean torchOn = false;
    boolean autoOn = false;

    private ImageView captureButton, image;
    private boolean isCaptureModeOn = false;

    private static final int PICK_IMAGE = 100;
    private static final String UPLOAD_URL = "https://9410-14-139-34-101.ngrok-free.app/restore";
    private OkHttpClient client = new OkHttpClient();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);

        textureView = findViewById(R.id.texture_view);
        isoText = findViewById(R.id.iso_text);
        shutterText = findViewById(R.id.shutter_text);
        blurResultText = findViewById(R.id.blur_result_text);
        isoSlider = findViewById(R.id.iso_slider);
        shutterSlider = findViewById(R.id.shutter_slider);
        exposureText = findViewById(R.id.exposure_text);
        isoTextView = findViewById(R.id.iso);
        shutterTextView = findViewById(R.id.shutter);

        captureButton = findViewById(R.id.capturebutton);

        blurClassifier = new BlurClassificationHelper(this);

        setupSliders();

        ImageView flash = findViewById(R.id.flashbutton);
        ImageView auto = findViewById(R.id.autobutton);

        image = findViewById(R.id.deblurimage);
        image.setOnClickListener(view -> {
            openGallery();
        });

        findViewById(R.id.flash).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (torchOn) {
                        Log.d("torch", "Turning off flashlight");
                        captureBuilder.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_OFF);
                        flash.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.baseline_flash_off_24, null));
                    } else {
                        Log.d("torch", "Turning on flashlight");
                        captureBuilder.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_TORCH);
                        flash.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.baseline_flash_on_24, null));
                    }
                    torchOn = !torchOn; // Toggle state


                    // Commit the updated request to apply the changes
                    cameraCaptureSession.setRepeatingRequest(captureBuilder.build(), null, null);

                } catch (CameraAccessException e) {
                    e.printStackTrace();
                }
            }
        });


        findViewById(R.id.auto).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    if (autoOn) {
                        Log.d("torch", "Turning off auto");
                        auto.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.baseline_auto_fix_off_24, null));
                    } else {
                        Log.d("torch", "Turning on auto");
                        auto.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.baseline_auto_fix_high_24, null));
                    }
                    autoOn = !autoOn; // Toggle state


            }
        });



        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA},
                    REQUEST_CAMERA_PERMISSION);
        } else {
            setupCamera();
        }

        captureButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!isCaptureModeOn) {
                    // Stop the preview
                    try {
                        if (cameraCaptureSession != null) {
                            cameraCaptureSession.stopRepeating();
                        }
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }
                } else {
                    // Resume the preview by creating a new capture session
                    try {
                        cameraDevice.createCaptureSession(Arrays.asList(surface),
                            new CameraCaptureSession.StateCallback() {
                                @Override
                                public void onConfigured(@NonNull CameraCaptureSession session) {
                                    cameraCaptureSession = session;
                                    updateCaptureSettings();
                                }

                                @Override
                                public void onConfigureFailed(@NonNull CameraCaptureSession session) {
                                    Toast.makeText(CameraActivity.this,
                                            "Camera configuration failed", Toast.LENGTH_SHORT).show();
                                }
                            }, null);
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }
                }
                isCaptureModeOn = !isCaptureModeOn;
            }
        });
    }

    


    private final TextureView.SurfaceTextureListener surfaceTextureListener = new TextureView.SurfaceTextureListener() {
        @Override
        public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
            openCamera();
        }

        @Override
        public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {
        }

        @Override
        public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) {
            return true;
        }

        @Override
        public void onSurfaceTextureUpdated(SurfaceTexture surface) {
            if (isCaptureModeOn) return;  // Don't process frames when in capture mode
            
            long currentTimestamp = System.currentTimeMillis();
            if (currentTimestamp - lastProcessedTimestamp >= PROCESS_INTERVAL_MS && autoOn) {
                lastProcessedTimestamp = currentTimestamp;

                // Capture the current frame from TextureView
                final Bitmap bitmap = textureView.getBitmap();
                if (bitmap != null) {
                    backgroundHandler.post(() -> processImage(bitmap));
                }
            }
        }
    };

//    float checkExposure(Bitmap bitmap){
//
//        int width = bitmap.getWidth();
//        int height = bitmap.getHeight();
//
//        // Sample pixels for efficiency (every 10th pixel)
//        int sampleStep = 10;
//        int pixelCount = 0;
//        long totalBrightness = 0;
//
//        for (int y = 0; y < height; y += sampleStep) {
//            for (int x = 0; x < width; x += sampleStep) {
//                int pixel = bitmap.getPixel(x, y);
//
//                // Extract RGB values
//                int r = (pixel >> 16) & 0xff;
//                int g = (pixel >> 8) & 0xff;
//                int b = pixel & 0xff;
//
//                // Calculate luminance using standard coefficients
//                float luminance = 0.299f * r + 0.587f * g + 0.114f * b;
//
//                totalBrightness += luminance;
//                pixelCount++;
//            }
//        }
//
//        float averageBrightness = (float) totalBrightness / pixelCount;
//        return averageBrightness;
//
//    }


    float checkExposure(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();

        // Sample pixels for efficiency (every 10th pixel)
        int sampleStep = 10;
        int pixelCount = 0;
        long totalBrightness = 0;

        for (int y = 0; y < height; y += sampleStep) {
            for (int x = 0; x < width; x += sampleStep) {
                int pixel = bitmap.getPixel(x, y);

                // Extract RGB values
                int r = (pixel >> 16) & 0xff;
                int g = (pixel >> 8) & 0xff;
                int b = pixel & 0xff;

                // Calculate luminance using standard coefficients
                float luminance = 0.299f * r + 0.587f * g + 0.114f * b;

                totalBrightness += luminance;
                pixelCount++;
            }
        }

        // Compute average luminance
        float averageBrightness = (float) totalBrightness / pixelCount;
        return averageBrightness;

    }

    private long lastShutterSpeedAdjustmentTime = 0;


    private void processImage(Bitmap bitmap) {
        BlurClassificationHelper.BlurPrediction prediction = blurClassifier.predict(bitmap);


        // Update UI on the main thread
        runOnUiThread(() -> {

            String label = prediction.isSharp() ? "Sharp" : "Blur";
            float score = prediction.getScore();

            String blur = "";
            if (score<0.3){
                blur = "Very High";
                blurResultText.setTextColor(Color.RED);
            } else if (score>=0.3 && score<0.6){
                blur = "Medium";
                blurResultText.setTextColor(Color.YELLOW);
            }  else if (score>=0.6 && score<=1){
                blur = "Minimal";
                blurResultText.setTextColor(Color.GREEN);
            }

            //String confidenceStr = String.format("%.2f", score);
            blurResultText.setText("Blur" + ": " + blur);



            float averageBrightness = checkExposure(bitmap);

            String brightness = "";
            if (averageBrightness<100){
                brightness = "Low";
                exposureText.setTextColor(Color.RED);
            } else if (averageBrightness>=100 && averageBrightness<200){
                exposureText.setTextColor(Color.GREEN);
                brightness = "Good";
            } else if (averageBrightness>=200){
                exposureText.setTextColor(Color.YELLOW);
                brightness = "High";
            }

            // Update exposure text
            exposureText.setText("Exposure: " + brightness);

            if(label.equals("Blur")){
                long currentTime = System.currentTimeMillis();
                if (currentTime - lastShutterSpeedAdjustmentTime >= 1000) {
                    decreaseShutterSpeed();
                    lastShutterSpeedAdjustmentTime = currentTime;
                }

            }
            adjustISOBasedOnExposure(averageBrightness);
            Log.d("iso", String.valueOf(averageBrightness));
        });

    }

    void decreaseShutterSpeed(){

        if (cameraCaptureSession == null || shutterSlider == null) return;

        int currentShutterIndex = shutterSlider.getProgress() / (shutterSlider.getMax() / (shutterSpeeds.length - 1));
        int newProgress = ((currentShutterIndex - 1) * shutterSlider.getMax()) / (shutterSpeeds.length - 1);
        shutterSlider.setProgress(newProgress);


    }

    private void adjustISOBasedOnExposure(float averageBrightness) {
        if (cameraCaptureSession == null || isoSlider == null) return;

        int currentIsoIndex = isoSlider.getProgress() / (isoSlider.getMax() / (isoValues.length - 1));

        if (averageBrightness<100 && currentIsoIndex < isoValues.length - 1) {
            // Increase ISO by one step
            int newProgress = ((currentIsoIndex + 1) * isoSlider.getMax()) / (isoValues.length - 1);
            isoSlider.setProgress(newProgress);
            // updateCaptureSettings() will be called by the slider's listener
        } else if (averageBrightness>200 && currentIsoIndex > 0) {
            // Decrease ISO by one step
            int newProgress = ((currentIsoIndex - 1) * isoSlider.getMax()) / (isoValues.length - 1);
            isoSlider.setProgress(newProgress);
            Log.d("seek", String.valueOf(newProgress));
            // updateCaptureSettings() will be called by the slider's listener
        }

        Log.d("iso123", String.valueOf(currentIsoIndex));

        if (currentIsoIndex == 0 && averageBrightness>200){

            int currentShutterIndex = shutterSlider.getProgress() / (shutterSlider.getMax() / (shutterSpeeds.length - 1));
            int newProgress = ((currentShutterIndex - 1) * shutterSlider.getMax()) / (shutterSpeeds.length - 1);
            shutterSlider.setProgress(newProgress);

        }
        if (currentIsoIndex > 4 && averageBrightness<=100){

            int currentShutterIndex = shutterSlider.getProgress() / (shutterSlider.getMax() / (shutterSpeeds.length - 1));
            int newProgress = ((currentShutterIndex + 1) * shutterSlider.getMax()) / (shutterSpeeds.length - 1);
            shutterSlider.setProgress(newProgress);

        }
    }



    private void startBackgroundThread() {
        backgroundThread = new HandlerThread("CameraBackground");
        backgroundThread.start();
        backgroundHandler = new Handler(backgroundThread.getLooper());
    }

    private void stopBackgroundThread() {
        if (backgroundThread != null) {
            backgroundThread.quitSafely();
            try {
                backgroundThread.join();
                backgroundThread = null;
                backgroundHandler = null;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private final CameraDevice.StateCallback stateCallback = new CameraDevice.StateCallback() {
        @Override
        public void onOpened(@NonNull CameraDevice camera) {
            cameraDevice = camera;
            startPreview();
        }

        @Override
        public void onDisconnected(@NonNull CameraDevice camera) {
            camera.close();
            cameraDevice = null;
        }

        @Override
        public void onError(@NonNull CameraDevice camera, int error) {
            camera.close();
            cameraDevice = null;
        }
    };


    private void setupSliders() {
        isoSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int index = progress / (isoSlider.getMax() / (isoValues.length - 1));
                int iso = isoValues[index];
//                isoText.setText("ISO: " + iso);

                isoTextView.setText("ISO "+iso);

                updateCaptureSettings();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        shutterSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int index = progress / (shutterSlider.getMax() / (shutterSpeeds.length - 1));
                long shutterSpeed = shutterSpeeds[index];
//                shutterText.setText(String.format("Shutter: 1/%ds", 1000000000 / shutterSpeed));

                shutterTextView.setText(String.format("Shutter: 1/%ds", 1000000000 / shutterSpeed));


                updateCaptureSettings();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        shutterSlider.setProgress(50);

    }

    private void setupCamera() {
        textureView.setSurfaceTextureListener(surfaceTextureListener);
    }


    Surface surface;


    private void openCamera() {
        CameraManager manager = (CameraManager) getSystemService(CAMERA_SERVICE);
        try {
            cameraId = manager.getCameraIdList()[0];

            CameraCharacteristics characteristics = manager.getCameraCharacteristics(cameraId);

            StreamConfigurationMap map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            Size[] sizes = map.getOutputSizes(SurfaceTexture.class);
            Size previewSize = sizes[6];
            for (Size size : sizes) {
                Log.d("sizes", size.toString());
            }

            // Set TextureView buffer size to match the selected preview size
            SurfaceTexture texture = textureView.getSurfaceTexture();
            if (texture != null) {
                texture.setDefaultBufferSize(1440, 1920);
            }

            surface = new Surface(texture);


            // Optionally, adjust TextureView layout to maintain aspect ratio
            ViewGroup.LayoutParams params = textureView.getLayoutParams();
            int screenWidth = getResources().getDisplayMetrics().widthPixels;
            params.height = (int) (screenWidth * ((float) 1920 / 1440));
            params.width = screenWidth;
            textureView.setLayoutParams(params);

//            texture.setDefaultBufferSize(previewSize.getWidth(), previewSize.getHeight());
//
//            params.height = (int) (screenWidth * ((float) previewSize.getHeight() / previewSize.getWidth()));
//            textureView.setLayoutParams(params);

            Range<Long> exposureRange = characteristics.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE);
            Range<Integer> isoRange = characteristics.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE);


            // Log supported ranges
            Log.d("cam", "Supported exposure times: " + exposureRange);
            Log.d("cam", "Supported ISO values: " + isoRange);

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            manager.openCamera(cameraId, stateCallback, null);
        } catch (CameraAccessException e) {
            e.printStackTrace();
            Toast.makeText(this, "Cannot access camera", Toast.LENGTH_SHORT).show();
        }
    }


    private void startPreview() {
//        SurfaceTexture texture = textureView.getSurfaceTexture();
//        texture.setDefaultBufferSize(1440, 1920);
//        Surface surface = new Surface(texture);

        try {
            captureBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            captureBuilder.addTarget(surface);
            captureBuilder.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);

            cameraDevice.createCaptureSession(Arrays.asList(surface),
                    new CameraCaptureSession.StateCallback() {
                        @Override
                        public void onConfigured(@NonNull CameraCaptureSession session) {
                            cameraCaptureSession = session;
                            updateCaptureSettings();
                        }

                        @Override
                        public void onConfigureFailed(@NonNull CameraCaptureSession session) {
                            Toast.makeText(CameraActivity.this,
                                    "Camera configuration failed", Toast.LENGTH_SHORT).show();
                        }
                    }, null);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    private void updateCaptureSettings() {
        if (cameraCaptureSession == null || captureBuilder == null || isCaptureModeOn) return;

        try {
            captureBuilder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF);

            int isoIndex = isoSlider.getProgress() / (isoSlider.getMax() / (isoValues.length - 1));
            captureBuilder.set(CaptureRequest.SENSOR_SENSITIVITY, isoValues[isoIndex]);

            int shutterIndex = shutterSlider.getProgress() / (shutterSlider.getMax() / (shutterSpeeds.length - 1));
            captureBuilder.set(CaptureRequest.SENSOR_EXPOSURE_TIME, shutterSpeeds[shutterIndex]);

            cameraCaptureSession.setRepeatingRequest(captureBuilder.build(), null, null);
        } catch (CameraAccessException e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to update camera settings", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                setupCamera();
            } else {
                Toast.makeText(this, "Camera permission denied", Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        startBackgroundThread();
        if (textureView.isAvailable()) {
            openCamera();
        } else {
            textureView.setSurfaceTextureListener(surfaceTextureListener);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (cameraDevice != null) {
            cameraDevice.close();
            cameraDevice = null;
        }
        stopBackgroundThread();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (blurClassifier != null) {
            blurClassifier.close();
        }
    }

    private void openGallery() {
        Intent gallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(gallery, PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == PICK_IMAGE) {
            Uri imageUri = data.getData();
            try {
                InputStream inputStream = getContentResolver().openInputStream(imageUri);
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                uploadImage(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(this, "Failed to read image", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void uploadImage(Bitmap bitmap) {
        ProgressDialog progress = new ProgressDialog(this);
        progress.setTitle("Processing");
        progress.setMessage("Please wait...");
        progress.show();

        new Thread(() -> {
            try {
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
                byte[] byteArray = stream.toByteArray();

                RequestBody requestBody = new MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart("file", "blurry_image.png",
                        RequestBody.create(MediaType.parse("image/png"), byteArray))
                    .build();

                Request request = new Request.Builder()
                    .url(UPLOAD_URL)
                    .post(requestBody)
                    .build();

                Response response = client.newCall(request).execute();
                if (response.isSuccessful()) {
                    byte[] responseData = response.body().bytes();
                    Bitmap resultBitmap = BitmapFactory.decodeByteArray(responseData, 0, responseData.length);
                    
                    runOnUiThread(() -> {
                        progress.dismiss();
                        showImageDialog(resultBitmap);
                    });
                } else {
                    runOnUiThread(() -> {
                        progress.dismiss();
                        Toast.makeText(CameraActivity.this, "Server error", Toast.LENGTH_SHORT).show();
                    });
                }
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> {
                    progress.dismiss();
                    Toast.makeText(CameraActivity.this, "Upload failed", Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }

    private void showImageDialog(Bitmap bitmap) {
        Dialog dialog = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        ImageView imageView = new ImageView(this);
        imageView.setImageBitmap(bitmap);
        imageView.setOnClickListener(v -> dialog.dismiss());
        dialog.setContentView(imageView);
        dialog.show();
    }

}