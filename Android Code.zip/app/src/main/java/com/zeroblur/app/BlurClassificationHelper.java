package com.zeroblur.app;

import android.content.Context;
import android.graphics.Bitmap;
import org.tensorflow.lite.Interpreter;
import org.tensorflow.lite.support.common.FileUtil;
import org.tensorflow.lite.support.common.ops.NormalizeOp;
import org.tensorflow.lite.support.image.ImageProcessor;
import org.tensorflow.lite.support.image.TensorImage;
import org.tensorflow.lite.support.image.ops.ResizeOp;
import org.tensorflow.lite.DataType;
import java.io.IOException;
import java.nio.MappedByteBuffer;

public class BlurClassificationHelper {
    private Interpreter tflite;
    private final float[][] outputBuffer = new float[1][1]; // Single output for binary classification

    public BlurClassificationHelper(Context context) {
        try {
            MappedByteBuffer modelFile = FileUtil.loadMappedFile(context, "blur_classifier_latest.tflite");
            tflite = new Interpreter(modelFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static class BlurPrediction {
        private final boolean isNotBlurred;
        private final float score;

        public BlurPrediction(boolean isNotBlurred, float score) {
            this.isNotBlurred = isNotBlurred;
            this.score = score;
        }

        public boolean isSharp() {
            return isNotBlurred;
        }

        public float getScore() {
            return score;
        }
    }

    public BlurPrediction predict(Bitmap bitmap) {
        // Create image processor for TensorFlow model input
        ImageProcessor imageProcessor = new ImageProcessor.Builder()
                .add(new ResizeOp(128, 128, ResizeOp.ResizeMethod.NEAREST_NEIGHBOR))
                .add(new NormalizeOp(0f, 255f))
                .build();

        // Create TensorImage for model input
        TensorImage tensorImage = new TensorImage(DataType.FLOAT32);
        tensorImage.load(bitmap);
        tensorImage = imageProcessor.process(tensorImage);

        // Run inference
        tflite.run(tensorImage.getBuffer(), outputBuffer);

        // Output is a single sigmoid value (0 to 1)
        float score = outputBuffer[0][0];
        boolean isNotBlurred = score > 0.5f; // Threshold at 0.5

        return new BlurPrediction(isNotBlurred, score);
    }

    public void close() {
        if (tflite != null) {
            tflite.close();
            tflite = null;
        }
    }
}